public class MineSweeper{
  public static void main(String args[]){
    Start start = new Start();
    start.gameStart();
  }
}